<html>
<head>
	<style type="text/css">
		div#content-inner-login {float:center; padding:0px 0 15px 0; margin:30px 50px 130px 50px; background-color:#fff;}
	</style>
</head>
<body><br /><br />
<div style="border:0; padding:10px; width:924px; height:auto;">
<center><div id="content-inner-login">
	<form action="login/login.php" method="POST"> 
		<table cellpadding="0" cellspacing="5" bgcolor="#B0C4DE">
			<tr height="36" bgcolor="#F8F8FF">
				<th colspan="5">Login Your Authorization:</th>
			</tr>
			<tr>
				<td>
					<table>
						<tr><br />
							<td><img src="image/admin.jpg" width="100" height="100" /></td>
							<td style="vertical-align: top">
							Username : <input type="text" name="username" placeholder=" Username" required autofocus size="21" maxlength="20" /><br />
							Password &nbsp;: <input type="password" name="password" placeholder=" Password" size="21" maxlength="20" /><br /><br />
							<input style="float:right" type="submit" value="LOGIN" /><br /></td>
						</tr>
						<tr height="10">
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</form>
</div></center>
</div>
</body>
</html>