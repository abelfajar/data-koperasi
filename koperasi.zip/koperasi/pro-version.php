<div style="border:0; padding:10px; width:924px; height:auto;"><br /><br /><br /><br /><br />
	<table width="720" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td width="100%">
			<h3>Selamat Datang di Aplikasi Koperasi Simpan Pinjam Online</h3>
			<p>MAAF, PROSES INI HANYA DAPAT BERJALAN DI APLIKASI VERSI PRO, SILAHKAN HUBUNGI ADMIN RajaPutraMedia.Com</p>
			<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
			</td>
		</tr>
	</table>
</div>